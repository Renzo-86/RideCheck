package com.ridecheck

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.text.NumberFormat
import java.util.Locale

class OverlayService : Service() {

    companion object {
        const val ACTION_START  = "com.ridecheck.OVERLAY_START"
        const val ACTION_UPDATE = "com.ridecheck.OVERLAY_UPDATE"
        const val ACTION_STOP   = "com.ridecheck.OVERLAY_STOP"
        private const val NOTIF_CHANNEL = "ridecheck_overlay"
        private const val NOTIF_ID = 1
    }

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val fmt = NumberFormat.getNumberInstance(Locale("es", "AR"))

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        addOverlayView()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START  -> { /* overlay ya creado en onCreate */ }
            ACTION_UPDATE -> handleUpdate(intent)
            ACTION_STOP   -> stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        overlayView?.let { windowManager?.removeView(it) }
    }

    // ── Crear la vista flotante ──
    private fun addOverlayView() {
        if (!android.provider.Settings.canDrawOverlays(this)) return

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val inflater = LayoutInflater.from(this)
        overlayView  = inflater.inflate(R.layout.overlay_widget, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16
            y = 80
        }

        windowManager?.addView(overlayView, params)
        setupDrag(overlayView!!, params)

        // Botón minimizar: hace el widget más pequeño
        overlayView?.findViewById<TextView>(R.id.btnMinimize)?.setOnClickListener {
            toggleMinimize()
        }

        // Tap en el widget: abre MainActivity
        overlayView?.setOnClickListener {
            val i = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(i)
        }
    }

    private var minimized = false
    private fun toggleMinimize() {
        minimized = !minimized
        val rateView    = overlayView?.findViewById<TextView>(R.id.tvRate)
        val verdictView = overlayView?.findViewById<TextView>(R.id.tvVerdict)
        val btnMin      = overlayView?.findViewById<TextView>(R.id.btnMinimize)
        rateView?.visibility    = if (minimized) View.GONE else View.VISIBLE
        verdictView?.visibility = if (minimized) View.GONE else View.VISIBLE
        btnMin?.text            = if (minimized) "+" else "–"
    }

    // ── Drag para mover el widget ──
    private fun setupDrag(view: View, params: WindowManager.LayoutParams) {
        var startX = 0; var startY = 0
        var initX  = 0; var initY  = 0
        var isDrag = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX.toInt()
                    startY = event.rawY.toInt()
                    initX  = params.x
                    initY  = params.y
                    isDrag = false
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX.toInt() - startX
                    val dy = event.rawY.toInt() - startY
                    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) isDrag = true
                    if (isDrag) {
                        params.x = initX + dx
                        params.y = initY + dy
                        windowManager?.updateViewLayout(view, params)
                    }
                    isDrag
                }
                else -> false
            }
        }
    }

    // ── Actualizar UI del overlay con el resultado ──
    private fun handleUpdate(intent: Intent) {
        val km      = intent.getFloatExtra("km",     0f)
        val precio  = intent.getFloatExtra("precio", 0f)
        val rateKm  = intent.getFloatExtra("rateKm", 0f)
        val neto    = intent.getFloatExtra("neto",   0f)
        val verdict = Verdict.valueOf(intent.getStringExtra("verdict") ?: "BAD")

        val (colorBar, colorText, verdictText) = when (verdict) {
            Verdict.GOOD       -> Triple(Color.parseColor("#00FF88"), Color.parseColor("#00FF88"), "CONVIENE ✓")
            Verdict.BORDERLINE -> Triple(Color.parseColor("#FFD60A"), Color.parseColor("#FFD60A"), "BORDERLINE")
            Verdict.BAD        -> Triple(Color.parseColor("#FF2D55"), Color.parseColor("#FF2D55"), "NO CONVIENE")
        }

        overlayView?.post {
            overlayView?.findViewById<View>(R.id.colorBar)
                ?.setBackgroundColor(colorBar)

            overlayView?.findViewById<TextView>(R.id.tvRate)?.apply {
                text      = "$${fmt.format(rateKm.toDouble())}/km"
                setTextColor(colorText)
            }

            overlayView?.findViewById<TextView>(R.id.tvVerdict)?.apply {
                text = "$verdictText · ${km}km · $${fmt.format(precio.toDouble())}"
            }
        }
    }

    // ── Notificación persistente (foreground service) ──
    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIF_CHANNEL,
                "RideCheck Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Widget flotante activo" }

            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }

        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(this, NOTIF_CHANNEL)
            .setContentTitle("RideCheck activo")
            .setContentText("Leyendo viajes de Uber automáticamente")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(NOTIF_ID, notif)
    }
}
