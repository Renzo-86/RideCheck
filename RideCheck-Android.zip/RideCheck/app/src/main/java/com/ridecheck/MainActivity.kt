package com.ridecheck

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: AppPrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = AppPrefs(this)
        setupViews()
        loadConfig()
    }

    override fun onResume() {
        super.onResume()
        updateStatusCard()
    }

    private fun setupViews() {
        // Botón accesibilidad
        findViewById<Button>(R.id.btnPermission).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // Botón overlay
        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                // Iniciar el overlay service
                startService(Intent(this, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_START
                })
            }
        }

        // Botón guardar
        findViewById<Button>(R.id.btnSave).setOnClickListener {
            saveConfig()
        }

        // Actualizar preview en tiempo real
        val watcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = updatePreview()
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }
        findViewById<EditText>(R.id.etConsumo).addTextChangedListener(watcher)
        findViewById<EditText>(R.id.etTanque).addTextChangedListener(watcher)
        findViewById<EditText>(R.id.etNafta).addTextChangedListener(watcher)
        findViewById<EditText>(R.id.etMinimo).addTextChangedListener(watcher)
    }

    private fun loadConfig() {
        findViewById<EditText>(R.id.etConsumo).setText(prefs.consumo.toString())
        findViewById<EditText>(R.id.etTanque).setText(prefs.tanque.toString())
        findViewById<EditText>(R.id.etNafta).setText(prefs.nafta.toString())
        findViewById<EditText>(R.id.etMinimo).setText(prefs.minimo.toString())
        updatePreview()
    }

    private fun saveConfig() {
        prefs.consumo = editFloat(R.id.etConsumo, 30f)
        prefs.tanque  = editFloat(R.id.etTanque,  12f)
        prefs.nafta   = editFloat(R.id.etNafta,   1200f)
        prefs.minimo  = editFloat(R.id.etMinimo,  350f)
        updatePreview()

        // Notificar al servicio del cambio
        sendBroadcast(Intent(UberReaderService.ACTION_CONFIG_CHANGED))

        findViewById<Button>(R.id.btnSave).text = "✓ GUARDADO"
        findViewById<Button>(R.id.btnSave).postDelayed({
            findViewById<Button>(R.id.btnSave).text = "GUARDAR CONFIGURACIÓN"
        }, 2000)
    }

    private fun updatePreview() {
        val consumo = editFloat(R.id.etConsumo, 30f)
        val tanque  = editFloat(R.id.etTanque,  12f)
        val nafta   = editFloat(R.id.etNafta,   1200f)
        val minimo  = editFloat(R.id.etMinimo,  350f)

        val costoKm   = nafta / consumo
        val kmTanque  = tanque * consumo
        val costTanq  = tanque * nafta
        val netoTanq  = kmTanque * minimo - costTanq

        val fmt = NumberFormat.getNumberInstance(Locale("es", "AR"))
        findViewById<TextView>(R.id.tvCostoKm).text   = "$${fmt.format(costoKm.toDouble())}/km"
        findViewById<TextView>(R.id.tvKmTanque).text  = "${kmTanque.toInt()} km"
        findViewById<TextView>(R.id.tvNetoTanque).text = "$${fmt.format(netoTanq.toDouble())}"
    }

    private fun updateStatusCard() {
        val accessOk = isAccessibilityEnabled()
        val overlayOk = Settings.canDrawOverlays(this)

        val dot   = findViewById<View>(R.id.statusDot)
        val title = findViewById<TextView>(R.id.statusTitle)
        val sub   = findViewById<TextView>(R.id.statusSub)

        when {
            accessOk && overlayOk -> {
                dot.setBackgroundResource(R.drawable.dot_active_green)
                title.text = "Servicio activo 🟢"
                sub.text   = "RideCheck está leyendo Uber automáticamente"
            }
            accessOk && !overlayOk -> {
                dot.setBackgroundResource(R.drawable.dot_active_yellow)
                title.text = "Falta permiso de overlay"
                sub.text   = "Tocá 'ACTIVAR OVERLAY' para ver el widget"
            }
            else -> {
                dot.setBackgroundResource(R.drawable.dot_inactive)
                title.text = "Servicio inactivo"
                sub.text   = "Activá el permiso de accesibilidad para comenzar"
            }
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val service = "$packageName/${UberReaderService::class.java.canonicalName}"
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains(service)
    }

    private fun editFloat(id: Int, default: Float): Float =
        findViewById<EditText>(id).text.toString().toFloatOrNull() ?: default
}
