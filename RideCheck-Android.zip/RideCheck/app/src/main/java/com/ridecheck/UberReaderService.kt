package com.ridecheck

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * UberReaderService
 * ─────────────────
 * Accessibility Service que observa la app de Uber Driver.
 * Cuando detecta una pantalla de oferta de viaje, extrae:
 *   • distancia en km
 *   • precio de la tarifa
 * y los envía al OverlayService para mostrar el resultado.
 *
 * Patrones de texto que busca (Uber puede cambiarlos entre versiones):
 *   km  →  "8,3 km"  "8.3 km"  "8 km"
 *   $   →  "$1.250"  "$ 1250"  "ARS 1.250"
 */
class UberReaderService : AccessibilityService() {

    companion object {
        const val ACTION_CONFIG_CHANGED = "com.ridecheck.CONFIG_CHANGED"

        // Regex para extraer kilómetros — acepta coma o punto como decimal
        private val KM_REGEX = Regex(
            """(\d{1,3}[.,]\d{1,2}|\d{1,3})\s*km""",
            RegexOption.IGNORE_CASE
        )

        // Regex para extraer precio — $1.250 / $ 1250 / ARS 1.250 / 1250
        private val PRICE_REGEX = Regex(
            """(?:\$|ARS)\s*(\d{1,2}[.,]\d{3}|\d{3,5})""",
            RegexOption.IGNORE_CASE
        )
    }

    private lateinit var prefs: AppPrefs
    private var lastKm: Float    = 0f
    private var lastPrecio: Float = 0f
    private var lastSentHash: Int = 0

    private val configReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            prefs = AppPrefs(applicationContext) // recargar config
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = AppPrefs(applicationContext)
        registerReceiver(configReceiver, IntentFilter(ACTION_CONFIG_CHANGED))
        // Arrancar el overlay al activar el servicio
        startService(Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_START
        })
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val root = rootInActiveWindow ?: return

        // Solo procesar si estamos en Uber
        val pkg = event.packageName?.toString() ?: return
        if (!pkg.startsWith("com.ubercab")) {
            root.recycle()
            return
        }

        // Recolectar todo el texto visible de la pantalla
        val allText = StringBuilder()
        collectText(root, allText)
        root.recycle()

        val screenText = allText.toString()

        // Buscar km y precio en el texto
        val km     = extractKm(screenText)
        val precio = extractPrecio(screenText)

        if (km != null && precio != null && km > 0f && precio > 0f) {
            // Evitar re-enviar el mismo viaje repetidamente
            val hash = km.hashCode() * 31 + precio.hashCode()
            if (hash == lastSentHash) return
            lastSentHash = hash
            lastKm = km
            lastPrecio = precio

            val result = prefs.evaluate(km, precio)
            sendToOverlay(result)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(configReceiver) } catch (_: Exception) {}
    }

    // ── Recorre el árbol de vistas y acumula texto ──
    private fun collectText(node: AccessibilityNodeInfo?, sb: StringBuilder) {
        node ?: return
        node.text?.let { sb.append(it).append(" ") }
        node.contentDescription?.let { sb.append(it).append(" ") }
        for (i in 0 until node.childCount) {
            collectText(node.getChild(i), sb)
        }
    }

    // ── Extraer km ──
    private fun extractKm(text: String): Float? {
        val match = KM_REGEX.find(text) ?: return null
        val raw = match.groupValues[1].replace(',', '.')
        return raw.toFloatOrNull()
    }

    // ── Extraer precio ──
    private fun extractPrecio(text: String): Float? {
        val match = PRICE_REGEX.find(text) ?: return null
        // Quitar separadores de miles
        val raw = match.groupValues[1]
            .replace(".", "")
            .replace(",", "")
        return raw.toFloatOrNull()
    }

    // ── Enviar resultado al OverlayService via Intent ──
    private fun sendToOverlay(result: TripResult) {
        startService(Intent(this, OverlayService::class.java).apply {
            action          = OverlayService.ACTION_UPDATE
            putExtra("km",      result.km)
            putExtra("precio",  result.precio)
            putExtra("rateKm",  result.rateKm)
            putExtra("neto",    result.neto)
            putExtra("verdict", result.verdict.name)
        })
    }
}
