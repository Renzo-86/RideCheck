package com.ridecheck

import android.content.Context
import android.content.SharedPreferences

class AppPrefs(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("ridecheck_prefs", Context.MODE_PRIVATE)

    var consumo: Float
        get() = prefs.getFloat("consumo", 30f)
        set(v) = prefs.edit().putFloat("consumo", v).apply()

    var tanque: Float
        get() = prefs.getFloat("tanque", 12f)
        set(v) = prefs.edit().putFloat("tanque", v).apply()

    var nafta: Float
        get() = prefs.getFloat("nafta", 1200f)
        set(v) = prefs.edit().putFloat("nafta", v).apply()

    var minimo: Float
        get() = prefs.getFloat("minimo", 350f)
        set(v) = prefs.edit().putFloat("minimo", v).apply()

    /** Costo de combustible por km */
    fun costPerKm(): Float = nafta / consumo

    /**
     * Evalúa un viaje.
     * @return TripResult con veredicto, ratio y ganancia neta
     */
    fun evaluate(km: Float, precio: Float): TripResult {
        val rateKm  = precio / km
        val costoKm = costPerKm()
        val neto    = precio - km * costoKm
        val ratio   = rateKm / minimo

        val verdict = when {
            ratio >= 1.10f -> Verdict.GOOD
            ratio >= 0.85f -> Verdict.BORDERLINE
            else           -> Verdict.BAD
        }
        return TripResult(km, precio, rateKm, neto, ratio, verdict)
    }
}

enum class Verdict { GOOD, BORDERLINE, BAD }

data class TripResult(
    val km: Float,
    val precio: Float,
    val rateKm: Float,
    val neto: Float,
    val ratio: Float,
    val verdict: Verdict
)
